import { NextRequest, NextResponse } from "next/server";

type CardType =
  | "hook"
  | "reason"
  | "food"
  | "comparison"
  | "howto"
  | "recipe"
  | "warning"
  | "closing";

type RawCard = {
  type?: CardType;
  title?: string;
  body?: string;
  details?: string[];
  goodItems?: string[];
  cautionItems?: string[];
  recipeSteps?: string[];
  imageKeyword?: string;
  badge?: string;
  sourceNote?: string;
  imageSearchQuery?: string;
};

const ALLOWED_TYPES: CardType[] = [
  "hook", "reason", "food", "comparison",
  "howto", "recipe", "warning", "closing"
];

function extractJson(text: string) {
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < 0) throw new Error("AI 응답에서 JSON을 찾지 못했습니다.");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function callOllama(prompt: string) {
  const base = process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434";
  const model = process.env.OLLAMA_MODEL || "gemma3:4b";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 300_000);

  try {
    const response = await fetch(`${base}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        prompt,
        stream: false,
        format: "json",
        keep_alive: "30m",
        options: {
          temperature: 0.35,
          num_ctx: 4096,
          num_predict: 2600
        }
      })
    });

    if (!response.ok) {
      const detail = await response.text();
      throw new Error(detail || "Ollama 호출에 실패했습니다.");
    }

    const data = await response.json();
    return extractJson(String(data.response || ""));
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("AI 생성 시간이 5분을 넘었습니다. 다른 프로그램을 닫고 다시 시도하세요.");
    }
    if (error instanceof TypeError) {
      throw new Error("Ollama 연결에 실패했습니다. Ollama 앱이 실행 중인지 확인하세요.");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function cleanList(value: unknown, max = 4) {
  if (!Array.isArray(value)) return [];
  return value.map(String).map(v => v.trim()).filter(Boolean).slice(0, max);
}

function normalizeCard(card: RawCard, index: number) {
  const fallbackTypes: CardType[] = [
    "hook", "reason", "food", "comparison",
    "howto", "recipe", "warning", "closing"
  ];
  const type = ALLOWED_TYPES.includes(card.type as CardType)
    ? (card.type as CardType)
    : fallbackTypes[index];

  return {
    type,
    title: String(card.title || `카드 ${index + 1}`).trim(),
    body: String(card.body || "").trim(),
    details: cleanList(card.details, 4),
    goodItems: cleanList(card.goodItems, 4),
    cautionItems: cleanList(card.cautionItems, 4),
    recipeSteps: cleanList(card.recipeSteps, 4),
    imageKeyword: String(card.imageKeyword || "checklist").trim(),
    badge: String(card.badge || (index === 0 ? "꼭 확인하세요" : `${index + 1}/8`)).trim(),
    sourceNote: String(card.sourceNote || "일반적인 건강·영양 정보 요약").trim(),
    imageSearchQuery: String(card.imageSearchQuery || card.imageKeyword || "healthy lifestyle").trim()
  };
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const topic = String(body.topic || "").trim();
  const category = String(body.category || "건강");
  const mode = String(body.mode || "auto");
  const audience = String(body.audience || "일반 성인");

  if (!topic) {
    return NextResponse.json({ error: "주제를 입력하세요." }, { status: 400 });
  }

  const prompt = `
당신은 한국 SNS 건강 콘텐츠 전문 기획자이자 검수자입니다.
아래 조건으로 인스타그램용 8장 캐러셀을 한 번에 완성하세요.

카테고리: ${category}
주제: ${topic}
콘텐츠 모드: ${mode}
대상 독자: ${audience}

구성:
1장 hook: 짧고 강한 제목
2장 reason: 왜 중요한지
3장 food: 구체적인 음식 또는 실천 예시 2~4개
4장 comparison: 추천 선택과 주의할 선택
5장 howto: 실제 실천 방법
6장 recipe: 간단한 조합 또는 실행 순서
7장 warning: 주의점과 상담이 필요한 신호
8장 closing: 핵심 요약과 저장 유도

규칙:
- 쉬운 한국어로 작성합니다.
- 카드 제목은 짧게, 본문은 2~3문장 이내로 작성합니다.
- 같은 내용을 반복하지 않습니다.
- 완치, 치료 보장, 해독, 무조건, 100% 같은 과장 표현을 쓰지 않습니다.
- 임신·약·보충제는 임의 복용이나 중단을 지시하지 않습니다.
- 확실하지 않은 수치와 연구 결과를 만들지 않습니다.
- 개인차와 의료진 상담이 필요한 상황을 자연스럽게 포함합니다.
- comparison은 goodItems와 cautionItems를 각각 2개 이상 작성합니다.
- recipe는 recipeSteps를 3개 이상 작성합니다.
- imageKeyword는 다음 중 하나만 사용합니다:
pregnant, water, food, walk, sleep, doctor, medicine, warning, heart, checklist,
baby, fruit, exercise, hospital, calendar, broccoli, kiwi, meal, recipe, compare,
skin, sun, pet, protein, vegetables

JSON만 출력하세요:
{
  "caption": "자연스러운 게시물 캡션 3~5문장",
  "hashtags": ["#태그1", "#태그2"],
  "cards": [
    {
      "type": "hook",
      "title": "",
      "body": "",
      "details": [],
      "goodItems": [],
      "cautionItems": [],
      "recipeSteps": [],
      "imageKeyword": "",
      "badge": "",
      "sourceNote": "일반적인 건강·영양 정보 요약",
      "imageSearchQuery": ""
    }
  ],
  "review": {
    "strengths": ["구체적인 실천 방법", "주의 상황 포함"],
    "checks": ["과장 표현", "임신·약물 안전 문구", "중복 내용", "근거 없는 수치"]
  },
  "planSummary": {
    "contentKind": "food 또는 symptom 또는 lifestyle",
    "coreQuestion": "독자가 가장 궁금해할 질문",
    "keyFacts": ["핵심 사실 1", "핵심 사실 2", "핵심 사실 3"]
  }
}
`;

  try {
    const result = await callOllama(prompt);
    const rawCards: RawCard[] = Array.isArray(result.cards) ? result.cards.slice(0, 8) : [];

    if (rawCards.length !== 8) {
      throw new Error("AI가 8장의 카드를 완성하지 못했습니다. 다시 생성하세요.");
    }

    const cards = rawCards.map(normalizeCard);
    const comparison = cards.find(c => c.type === "comparison");
    const recipe = cards.find(c => c.type === "recipe");

    if (comparison && comparison.goodItems.length < 2) {
      comparison.goodItems = ["균형 잡힌 선택", "개인 상태에 맞춘 선택"];
    }
    if (comparison && comparison.cautionItems.length < 2) {
      comparison.cautionItems = ["과도한 섭취", "증상이 있는데 무리하기"];
    }
    if (recipe && recipe.recipeSteps.length < 3) {
      recipe.recipeSteps = ["재료를 준비합니다.", "간단하게 조리합니다.", "개인 상태에 맞게 양을 조절합니다."];
    }

    const allText = cards
      .map(c => [c.title, c.body, ...c.details, ...c.goodItems, ...c.cautionItems, ...c.recipeSteps].join(" "))
      .join(" ");

    const riskyWords = ["완치", "치료됩니다", "무조건", "100%", "해독", "기적", "즉시 낫"];
    const riskyCount = riskyWords.filter(word => allText.includes(word)).length;
    const concreteCards = cards.filter(
      c => c.details.length >= 2 || c.goodItems.length >= 2 || c.recipeSteps.length >= 3
    ).length;
    const duplicateTitles =
      cards.length - new Set(cards.map(c => c.title.replace(/\s/g, ""))).size;
    const score = Math.max(
      70,
      Math.min(98, 82 + concreteCards * 2 - riskyCount * 8 - duplicateTitles * 4)
    );

    return NextResponse.json({
      caption: String(result.caption || ""),
      hashtags: cleanList(result.hashtags, 12),
      cards,
      quality: {
        score,
        strengths: cleanList(result?.review?.strengths, 4).length
          ? cleanList(result.review.strengths, 4)
          : ["구체적인 실천 방법", "주의 상황 포함", "과장 표현 점검"],
        checks: cleanList(result?.review?.checks, 4).length
          ? cleanList(result.review.checks, 4)
          : ["과장 표현", "임신·약물 안전 문구", "중복 내용", "근거 없는 수치"]
      },
      planSummary: {
        contentKind: String(result?.planSummary?.contentKind || ""),
        coreQuestion: String(result?.planSummary?.coreQuestion || ""),
        keyFacts: cleanList(result?.planSummary?.keyFacts, 4)
      }
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "생성 중 오류가 발생했습니다."
      },
      { status: 500 }
    );
  }
}
